
    import React, { createContext, useContext, useState, useEffect } from 'react';
    import { getSupabase, initializeSupabase } from '@/lib/supabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { useI18n } from '@/lib/i18n';
    
    const AuthContext = createContext({
      user: null,
      signInWithGoogle: () => {},
      signOut: () => {},
      loading: true,
      isSupabaseConfigured: false,
    });
    
    export const AuthProvider = ({ children }) => {
      const [user, setUser] = useState(null);
      const [loading, setLoading] = useState(true);
      const [isSupabaseConfigured, setIsSupabaseConfigured] = useState(false);
      const { toast } = useToast();
      const { t } = useI18n();
    
      useEffect(() => {
        const supabaseUrl = "https://qcpjtbdurwrsckbrtzwn.supabase.co";
        const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFjcGp0YmR1cndyc2NrYnJ0enduIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDcxNDA2NTIsImV4cCI6MjA2MjcxNjY1Mn0.cF-Uwp4QipLmHGWP_vRyL2OGNX6BWYSwso7vMHXZCDc";
    
        if (supabaseUrl && supabaseKey) {
          initializeSupabase(supabaseUrl, supabaseKey);
          setIsSupabaseConfigured(true);
          const supabase = getSupabase();
    
          const getSession = async () => {
            const { data: { session } } = await supabase.auth.getSession();
            setUser(session?.user ?? null);
            setLoading(false);
          };
          getSession();
    
          const { data: authListener } = supabase.auth.onAuthStateChange(
            async (event, session) => {
              setUser(session?.user ?? null);
              setLoading(false);
            }
          );
    
          return () => {
            authListener?.subscription.unsubscribe();
          };
        } else {
          console.warn("Supabase credentials not directly provided in AuthContext.");
          setLoading(false);
          setIsSupabaseConfigured(false);
          toast({
            title: t('auth.configErrorTitle'),
            description: t('auth.supabaseCredentialsMissing'),
            variant: "destructive",
          });
        }
      }, [toast, t]);
    
      const signInWithGoogle = async () => {
        if (!isSupabaseConfigured) {
          toast({
            title: t('auth.configErrorTitle'),
            description: t('auth.supabaseNotConfiguredAdmin'),
            variant: "destructive",
          });
          return;
        }
        const supabase = getSupabase();
        setLoading(true);
        const { error } = await supabase.auth.signInWithOAuth({
          provider: 'google',
          options: {
            redirectTo: window.location.origin
          }
        });
        if (error) {
          toast({
            title: t('auth.signInErrorTitle'),
            description: error.message,
            variant: "destructive",
          });
          console.error('Error signing in with Google:', error);
        }
        setLoading(false);
      };
    
      const signOut = async () => {
        if (!isSupabaseConfigured) {
          toast({
            title: t('auth.configErrorTitle'),
            description: t('auth.supabaseNotConfiguredAdmin'),
            variant: "destructive",
          });
          return;
        }
        const supabase = getSupabase();
        setLoading(true);
        const { error } = await supabase.auth.signOut();
        if (error) {
          toast({
            title: t('auth.signOutErrorTitle'),
            description: error.message,
            variant: "destructive",
          });
          console.error('Error signing out:', error);
        }
        setUser(null);
        setLoading(false);
      };
    
      return (
        <AuthContext.Provider value={{ user, signInWithGoogle, signOut, loading, isSupabaseConfigured }}>
          {children}
        </AuthContext.Provider>
      );
    };
    
    export const useAuth = () => useContext(AuthContext);
  