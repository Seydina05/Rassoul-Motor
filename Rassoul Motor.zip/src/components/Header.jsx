
    import React from 'react';
    import { Link, NavLink } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import {
      DropdownMenu,
      DropdownMenuContent,
      DropdownMenuItem,
      DropdownMenuLabel,
      DropdownMenuSeparator,
      DropdownMenuTrigger,
    } from '@/components/ui/dropdown-menu';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { Car, DollarSign, Globe, Home, LogIn, LogOut, MessageSquare, Bike as Motorcycle, Search, User, Wrench, Menu as MenuIcon } from 'lucide-react';
    import { useI18n } from '@/lib/i18n';
    import { useCurrency } from '@/lib/currency';
    import { useAuth } from '@/contexts/AuthContext';
    import { motion } from 'framer-motion';
    import { cn } from '@/lib/utils';
    
    const Header = () => {
      const { t, setLanguage, language } = useI18n();
      const { setCurrency, currency, currencies } = useCurrency();
      const { user, signOut, loading, isSupabaseConfigured } = useAuth();
      const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
    
      const navLinks = [
        { to: "/", label: t('nav.home'), icon: <Home className="mr-2 h-4 w-4" /> },
        { to: "/cars", label: t('nav.cars'), icon: <Car className="mr-2 h-4 w-4" /> },
        { to: "/motorcycles", label: t('nav.motorcycles'), icon: <Motorcycle className="mr-2 h-4 w-4" /> },
        { to: "/rentals", label: t('nav.rentals'), icon: <Wrench className="mr-2 h-4 w-4" /> },
        { to: "/sell", label: t('nav.sell'), icon: <DollarSign className="mr-2 h-4 w-4" /> },
        { to: "/messages", label: t('nav.messages'), icon: <MessageSquare className="mr-2 h-4 w-4" /> },
        { to: "/help", label: t('nav.help'), icon: <Search className="mr-2 h-4 w-4" /> },
      ];
    
      const NavItem = ({ to, label, icon }) => (
        <NavLink
          to={to}
          className={({ isActive }) =>
            cn(
              "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 ease-in-out",
              isActive 
                ? "bg-primary/20 text-primary dark:bg-primary/30 dark:text-primary-foreground" 
                : "text-muted-foreground hover:bg-accent/50 hover:text-accent-foreground dark:hover:bg-accent/20"
            )
          }
          onClick={() => setMobileMenuOpen(false)}
        >
          {icon}
          {label}
        </NavLink>
      );
    
      const UserMenu = () => {
        if (loading) {
          return <Button variant="ghost" size="icon" className="animate-pulse"><User className="h-5 w-5 text-primary" /></Button>;
        }
    
        if (!isSupabaseConfigured) {
           return (
            <Button asChild variant="ghost" size="icon" className="hover:bg-primary/10 transition-colors duration-300">
              <Link to="/auth">
                <LogIn className="h-5 w-5 text-primary" />
              </Link>
            </Button>
          );
        }
    
        if (user) {
          return (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user.user_metadata?.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.email || 'User')}&background=random`} alt={user.email || 'User avatar'} />
                    <AvatarFallback>{user.email?.[0]?.toUpperCase() || 'U'}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 glassmorphism border-primary/30">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.user_metadata?.full_name || user.email}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.email}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { signOut(); setMobileMenuOpen(false); }} className="cursor-pointer">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t('auth.signOut')}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          );
        }
    
        return (
          <Button asChild variant="ghost" size="icon" className="hover:bg-primary/10 transition-colors duration-300">
            <Link to="/auth">
              <LogIn className="h-5 w-5 text-primary" />
            </Link>
          </Button>
        );
      };
    
      return (
        <motion.header 
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
          className="sticky top-0 z-50 shadow-lg glassmorphism"
        >
          <div className="container mx-auto px-4">
            <div className="flex h-20 items-center justify-between">
              <Link to="/" className="flex items-center space-x-2" onClick={() => setMobileMenuOpen(false)}>
                <img  alt="Rassoul Motor Logo" className="h-10 w-auto" src="https://images.unsplash.com/photo-1517318379789-5dbb1ba118e0" />
                <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">{t('appName')}</span>
              </Link>
    
              <nav className="hidden md:flex items-center space-x-2 lg:space-x-4">
                {navLinks.map(link => <NavItem key={link.to} {...link} />)}
              </nav>
    
              <div className="flex items-center space-x-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="hover:bg-primary/10 transition-colors duration-300">
                      <Globe className="h-5 w-5 text-primary" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glassmorphism border-primary/30">
                    <DropdownMenuLabel>{t('selectLang')}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setLanguage('fr')} className={cn("cursor-pointer", language === 'fr' ? 'bg-accent/50' : '')}>
                      {t('french')} {language === 'fr' && '✓'}
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setLanguage('en')} className={cn("cursor-pointer", language === 'en' ? 'bg-accent/50' : '')}>
                      {t('english')} {language === 'en' && '✓'}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
    
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="hover:bg-primary/10 transition-colors duration-300">
                      <DollarSign className="h-5 w-5 text-primary" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glassmorphism border-primary/30">
                    <DropdownMenuLabel>{t('currency.eur')}/{t('currency.usd')}/{t('currency.cfa')}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {Object.entries(currencies).map(([code, { name }]) => (
                      <DropdownMenuItem key={code} onClick={() => setCurrency(code)} className={cn("cursor-pointer", currency === code ? 'bg-accent/50' : '')}>
                        {name} ({code}) {currency === code && '✓'}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                
                <div className="hidden md:block">
                  <UserMenu />
                </div>
    
                <div className="md:hidden">
                  <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="hover:bg-primary/10 transition-colors duration-300">
                    <MenuIcon className="h-6 w-6 text-primary" />
                  </Button>
                </div>
              </div>
            </div>
            
            {mobileMenuOpen && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className="md:hidden pb-4 space-y-2 border-t border-border"
              >
                {navLinks.map(link => <NavItem key={`mobile-${link.to}`} {...link} />)}
                
                <div className="pt-2 border-t border-border/50 mt-2">
                  {isSupabaseConfigured && user ? (
                    <Button variant="outline" onClick={() => { signOut(); setMobileMenuOpen(false); }} className="w-full justify-start">
                      <LogOut className="mr-2 h-4 w-4"/> {t('auth.signOut')}
                    </Button>
                  ) : (
                    <Button asChild variant="outline" className="w-full justify-start">
                      <Link to="/auth" onClick={() => setMobileMenuOpen(false)}>
                        <LogIn className="mr-2 h-4 w-4"/> {t('auth.signInUp')}
                      </Link>
                    </Button>
                  )}
                </div>
              </motion.div>
            )}
          </div>
        </motion.header>
      );
    };
    
    export default Header;
  