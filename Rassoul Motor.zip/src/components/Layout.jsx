
import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from '@/components/Header';
import { Toaster } from '@/components/ui/toaster';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';

const Footer = () => {
  const { t } = useI18n();
  return (
    <footer className="bg-gradient-to-r from-gray-800 via-gray-900 to-black text-primary-foreground py-8 mt-auto">
      <div className="container mx-auto text-center">
        <p>&copy; {new Date().getFullYear()} {t('appName')}. {t('footer.rights')}</p>
      </div>
    </footer>
  );
};

const Layout = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-background via-slate-50 to-secondary dark:from-slate-900 dark:via-slate-800 dark:to-background">
      <Header />
      <motion.main 
        className="flex-grow container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Outlet />
      </motion.main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default Layout;
  