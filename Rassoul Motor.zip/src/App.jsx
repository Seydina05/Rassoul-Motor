
    import React from 'react';
    import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
    import Layout from '@/components/Layout';
    import HomePage from '@/pages/HomePage';
    import CarsPage from '@/pages/CarsPage';
    import MotorcyclesPage from '@/pages/MotorcyclesPage';
    import RentalsPage from '@/pages/RentalsPage';
    import SellPage from '@/pages/SellPage';
    import MessagesPage from '@/pages/MessagesPage';
    import HelpPage from '@/pages/HelpPage';
    import AuthPage from '@/pages/AuthPage';
    import NotFoundPage from '@/pages/NotFoundPage';
    import { I18nProvider } from '@/lib/i18n';
    import { CurrencyProvider } from '@/lib/currency';
    import { AuthProvider } from '@/contexts/AuthContext';
    import { Toaster } from "@/components/ui/toaster";
    
    function App() {
      return (
        <I18nProvider>
          <CurrencyProvider>
            <AuthProvider>
              <Router>
                <Routes>
                  <Route path="/" element={<Layout />}>
                    <Route index element={<HomePage />} />
                    <Route path="cars" element={<CarsPage />} />
                    <Route path="motorcycles" element={<MotorcyclesPage />} />
                    <Route path="rentals" element={<RentalsPage />} />
                    <Route path="sell" element={<SellPage />} />
                    <Route path="messages" element={<MessagesPage />} />
                    <Route path="help" element={<HelpPage />} />
                    <Route path="auth" element={<AuthPage />} />
                    <Route path="*" element={<NotFoundPage />} />
                  </Route>
                </Routes>
              </Router>
              <Toaster />
            </AuthProvider>
          </CurrencyProvider>
        </I18nProvider>
      );
    }
    
    export default App;
  