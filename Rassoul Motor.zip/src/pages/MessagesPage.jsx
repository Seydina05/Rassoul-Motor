
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'; // Needs to be created
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, UserCircle } from 'lucide-react';
import { motion } from 'framer-motion';

// Placeholder for Avatar component if not created from shadcn/ui
const PlaceholderAvatar = ({ src, fallbackText, alt, className }) => (
  <div className={`h-10 w-10 rounded-full bg-muted flex items-center justify-center overflow-hidden ${className}`}>
    {src ? <img src={src} alt={alt || "Avatar"} className="h-full w-full object-cover" /> : <span className="text-sm font-medium text-muted-foreground">{fallbackText}</span>}
  </div>
);
PlaceholderAvatar.displayName = "Avatar";

const AvatarFallbackComponent = ({ children }) => <div className="flex items-center justify-center h-full w-full bg-secondary text-secondary-foreground">{children}</div>;


const dummyConversations = [
  { id: 1, name: 'Jean Dupont', lastMessage: 'Bonjour, la voiture est-elle toujours disponible ?', unread: 2, avatarFallback: 'JD' },
  { id: 2, name: 'Amina Diallo', lastMessage: 'Ok, je vous recontacte demain.', unread: 0, avatarFallback: 'AD' },
  { id: 3, name: 'VendeurPro77', lastMessage: 'Votre offre est intéressante, parlons-en.', unread: 0, avatarFallback: 'VP' },
];

const dummyMessages = [
    { id: 1, sender: 'Jean Dupont', text: 'Bonjour, la voiture est-elle toujours disponible ?', time: '10:30 AM', sentByMe: false },
    { id: 2, sender: 'Moi', text: 'Oui, elle l\'est. Intéressé ?', time: '10:32 AM', sentByMe: true },
    { id: 3, sender: 'Jean Dupont', text: 'Oui, très. Possible de la voir cette semaine ?', time: '10:35 AM', sentByMe: false },
];

const MessagesPage = () => {
  const { t } = useI18n();
  const [selectedConversation, setSelectedConversation] = React.useState(dummyConversations[0]);
  const [newMessage, setNewMessage] = React.useState('');

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (newMessage.trim() === '') return;
    // Logic to send message
    console.log("Sending message:", newMessage);
    setNewMessage('');
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col md:flex-row h-[calc(100vh-10rem)] gap-4"
    >
      {/* Conversations List */}
      <motion.div 
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="w-full md:w-1/3 lg:w-1/4"
      >
        <Card className="h-full overflow-y-auto glassmorphism border-primary/20">
          <CardHeader className="sticky top-0 bg-card/80 backdrop-blur-sm z-10">
            <CardTitle className="text-2xl text-primary">{t('messagesPageTitle')}</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {dummyConversations.map((conv) => (
              <div
                key={conv.id}
                className={`flex items-center p-4 cursor-pointer hover:bg-accent/10 transition-colors ${selectedConversation?.id === conv.id ? 'bg-accent/20' : ''}`}
                onClick={() => setSelectedConversation(conv)}
              >
                <PlaceholderAvatar fallbackText={conv.avatarFallback} className="mr-3" />
                <div className="flex-grow">
                  <p className="font-semibold">{conv.name}</p>
                  <p className="text-sm text-muted-foreground truncate">{conv.lastMessage}</p>
                </div>
                {conv.unread > 0 && (
                  <span className="ml-2 bg-primary text-primary-foreground text-xs font-bold px-2 py-1 rounded-full">
                    {conv.unread}
                  </span>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </motion.div>

      {/* Chat Area */}
      <motion.div 
        initial={{ x: 50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="w-full md:w-2/3 lg:w-3/4 flex flex-col"
      >
        {selectedConversation ? (
          <Card className="h-full flex flex-col glassmorphism border-primary/20">
            <CardHeader className="flex flex-row items-center space-x-3 p-4 border-b">
              <PlaceholderAvatar fallbackText={selectedConversation.avatarFallback} />
              <CardTitle className="text-xl text-primary">{selectedConversation.name}</CardTitle>
            </CardHeader>
            <CardContent className="flex-grow overflow-y-auto p-4 space-y-4">
              {dummyMessages.map(msg => (
                <div key={msg.id} className={`flex ${msg.sentByMe ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs lg:max-w-md p-3 rounded-lg ${msg.sentByMe ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                    <p>{msg.text}</p>
                    <p className={`text-xs mt-1 ${msg.sentByMe ? 'text-primary-foreground/70 text-right' : 'text-muted-foreground text-left'}`}>{msg.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
            <form onSubmit={handleSendMessage} className="p-4 border-t flex items-center space-x-2 bg-card/80 backdrop-blur-sm">
              <Input 
                type="text" 
                placeholder={t('messages.typeMessage') || "Écrire un message..."} 
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                className="flex-grow"
              />
              <Button type="submit" size="icon" className="bg-primary hover:bg-primary/90">
                <Send className="h-5 w-5" />
              </Button>
            </form>
          </Card>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-lg">
            {t('messages.selectConversation') || "Sélectionnez une conversation pour commencer à discuter."}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default MessagesPage;
  