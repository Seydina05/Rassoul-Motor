
import React, { useState } from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { motion } from 'framer-motion';
import { CheckCircle, DollarSign, Fuel, Users, Zap } from 'lucide-react';

const PlaceholderSlider = ({ defaultValue, max, step, onValueChange, className, ...props }) => {
  const [value, setValue] = useState(defaultValue[0]);
  const handleChange = (event) => {
    const newValue = parseFloat(event.target.value);
    setValue(newValue);
    if (onValueChange) {
      onValueChange([newValue]);
    }
  };
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <input type="range" min="0" max={max} step={step} defaultValue={defaultValue[0]} onChange={handleChange} className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700" {...props} />
      <span className="text-sm text-muted-foreground w-12 text-right">{value}</span>
    </div>
  );
};
PlaceholderSlider.displayName = "Slider";

const dummySuggestions = [
  { id: 1, name: 'Citadine Électrique Agile', type: 'Électrique', budget: 'Faible', usage: 'Ville', seats: 2, imageKey: 'Small electric city car white' },
  { id: 2, name: 'SUV Hybride Familial', type: 'Hybride', budget: 'Moyen', usage: 'Mixte', seats: 5, imageKey: 'Mid-size hybrid SUV silver' },
  { id: 3, name: 'Berline Diesel Routière', type: 'Diesel', budget: 'Élevé', usage: 'Route', seats: 5, imageKey: 'Large diesel sedan black for highways' },
  { id: 4, name: 'Moto Roadster Économique', type: 'Essence', budget: 'Faible', usage: 'Ville', seats: 1, imageKey: 'Economic roadster motorcycle red' },
];

const HelpPage = () => {
  const { t } = useI18n();
  const [criteria, setCriteria] = useState({
    usage: '',
    budget: [20000],
    seats: '',
    fuelType: '',
  });
  const [suggestions, setSuggestions] = useState([]);

  const handleCriteriaChange = (key, value) => {
    setCriteria(prev => ({ ...prev, [key]: value }));
  };

  const findSuggestions = () => {
    const filtered = dummySuggestions.filter(car => {
      let match = true;
      if (criteria.usage && car.usage.toLowerCase() !== criteria.usage.toLowerCase()) match = false;
      if (criteria.budget[0] < 10000 && car.budget !== 'Faible') match = false;
      if (criteria.budget[0] >= 10000 && criteria.budget[0] < 30000 && car.budget !== 'Moyen') match = false;
      if (criteria.budget[0] >= 30000 && car.budget !== 'Élevé') match = false;
      if (criteria.seats && car.seats < parseInt(criteria.seats)) match = false;
      if (criteria.fuelType && car.type.toLowerCase() !== criteria.fuelType.toLowerCase()) match = false;
      return match;
    });
    setSuggestions(filtered.length > 0 ? filtered : [{ id: 'none', name: t('help.noResults') || "Aucun véhicule ne correspond parfaitement, essayez d'élargir vos critères.", imageKey: "Question mark icon" }]);
  };

  const criteriaOptions = {
    usage: [
      { value: 'Ville', label: t('help.city') || 'Ville', icon: <Users className="mr-2 h-4 w-4" /> },
      { value: 'Route', label: t('help.highway') || 'Route', icon: <Fuel className="mr-2 h-4 w-4" /> },
      { value: 'Mixte', label: t('help.mixed') || 'Mixte', icon: <CheckCircle className="mr-2 h-4 w-4" /> },
    ],
    seats: [
      { value: '2', label: t('help.seats2') || '2 sièges' }, { value: '4', label: t('help.seats4') || '4 sièges' }, 
      { value: '5', label: t('help.seats5') || '5 sièges' }, { value: '7', label: t('help.seats7') || '7+ sièges' }
    ],
    fuelType: [
      { value: 'Essence', label: t('help.petrol') || 'Essence', icon: <Fuel className="mr-2 h-4 w-4" /> },
      { value: 'Diesel', label: t('help.diesel') || 'Diesel', icon: <Fuel className="mr-2 h-4 w-4 opacity-70" /> },
      { value: 'Hybride', label: t('help.hybrid') || 'Hybride', icon: <Zap className="mr-2 h-4 w-4 text-green-500" /> },
      { value: 'Électrique', label: t('help.electric') || 'Électrique', icon: <Zap className="mr-2 h-4 w-4 text-blue-500" /> },
    ],
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-12"
    >
      <header className="py-10 bg-gradient-to-br from-accent to-primary rounded-lg shadow-xl text-center">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-extrabold text-primary-foreground mb-3">{t('helpPageTitle')}</h1>
          <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
            {t('help.subtitle') || "Indiquez-nous vos besoins, nous vous aiderons à trouver le véhicule idéal."}
          </p>
        </div>
      </header>

      <Card className="max-w-3xl mx-auto p-6 md:p-8 shadow-2xl glassmorphism border-primary/20">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold text-primary">{t('help.defineCriteria') || 'Définissez vos critères'}</CardTitle>
          <CardDescription>{t('help.criteriaDescription') || 'Plus vous êtes précis, meilleures seront les suggestions.'}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-foreground/90 mb-1">{t('help.mainUsage') || "Usage principal"}</label>
            <Select onValueChange={(value) => handleCriteriaChange('usage', value)}>
              <SelectTrigger><SelectValue placeholder={t('help.selectUsage') || "Choisir un usage"} /></SelectTrigger>
              <SelectContent>
                {criteriaOptions.usage.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.icon}{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-foreground/90 mb-1">
              {t('help.budget') || "Budget approximatif"} ({criteria.budget[0]} €)
            </label>
            <div className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5 text-muted-foreground" />
              <PlaceholderSlider defaultValue={[20000]} max={100000} step={1000} onValueChange={(value) => handleCriteriaChange('budget', value)} className="w-full" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-foreground/90 mb-1">{t('help.numSeats') || "Nombre de places"}</label>
              <Select onValueChange={(value) => handleCriteriaChange('seats', value)}>
                <SelectTrigger><SelectValue placeholder={t('help.selectSeats') || "Choisir nombre de places"} /></SelectTrigger>
                <SelectContent>
                  {criteriaOptions.seats.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground/90 mb-1">{t('help.fuelType') || "Type de carburant/motorisation"}</label>
              <Select onValueChange={(value) => handleCriteriaChange('fuelType', value)}>
                <SelectTrigger><SelectValue placeholder={t('help.selectFuel') || "Choisir un type"} /></SelectTrigger>
                <SelectContent>
                  {criteriaOptions.fuelType.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.icon}{opt.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={findSuggestions} size="lg" className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground text-lg py-3">
            {t('help.findSuggestions') || "Trouver des suggestions"}
          </Button>
        </CardFooter>
      </Card>

      {suggestions.length > 0 && (
        <motion.section 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          <h2 className="text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
            {t('help.ourSuggestions') || 'Nos Suggestions Pour Vous'}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {suggestions.map((car, index) => (
              <motion.div
                key={car.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
              <Card className="overflow-hidden h-full flex flex-col hover:shadow-xl transition-shadow duration-300 glassmorphism border-primary/20">
                 <div className="relative h-56 w-full bg-secondary flex items-center justify-center">
                    <img className="w-full h-full object-cover" alt={car.name} src="https://images.unsplash.com/photo-1600682473578-3b7d57315b95" />
                  </div>
                <CardHeader>
                  <CardTitle className="text-xl font-semibold text-primary">{car.name}</CardTitle>
                  {car.id !== 'none' && <CardDescription>{t('help.type') || 'Type'}: {car.type} - {t('help.budgetCat') || 'Budget'}: {car.budget}</CardDescription>}
                </CardHeader>
                {car.id !== 'none' && 
                  <CardContent className="flex-grow">
                    <p>{t('help.idealFor') || 'Idéal pour'}: {car.usage} - {t('help.seats') || 'Places'}: {car.seats}</p>
                  </CardContent>
                }
                {car.id !== 'none' &&
                  <CardFooter>
                    <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground">
                      {t('help.seeDetails') || "Voir les détails"}
                    </Button>
                  </CardFooter>
                }
              </Card>
              </motion.div>
            ))}
          </div>
        </motion.section>
      )}
    </motion.div>
  );
};

export default HelpPage;
