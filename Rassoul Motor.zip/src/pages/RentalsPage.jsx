
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { CalendarDays } from 'lucide-react';
import { useCurrency } from '@/lib/currency';

const dummyRentals = [
  { id: 1, name: 'Compacte pour la ville', pricePerDay: 30, currency: 'EUR', imageKey: 'Small blue compact car for city rental', type: 'Voiture' },
  { id: 2, name: 'Minivan pour famille', pricePerDay: 70, currency: 'USD', imageKey: 'Silver minivan for family rental', type: 'Voiture' },
  { id: 3, name: 'Scooter 125cc', pricePerDay: 20, currency: 'EUR', imageKey: 'Red 125cc scooter for rental', type: 'Moto' },
  { id: 4, name: 'Vélo électrique', pricePerDay: 15000, currency: 'XOF', imageKey: 'Electric bike for city rental', type: 'Autre' },
];

const RentalsPage = () => {
  const { t } = useI18n();
  const { formatPrice, convertPrice, currency: currentGlobalCurrency } = useCurrency();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      <header className="py-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg shadow-lg">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center text-white">{t('rentalsPageTitle')}</h1>
          <p className="text-xl text-center text-indigo-100 mt-2">Louez facilement pour vos déplacements.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dummyRentals.map((rental, index) => (
          <motion.div
            key={rental.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden h-full flex flex-col hover:shadow-2xl transition-shadow duration-300 glassmorphism border-blue-500/30">
              <div className="relative h-56 w-full">
                <img className="w-full h-full object-cover" alt={rental.name} src="https://images.unsplash.com/photo-1685279053124-f47a436a9c1e" />
              </div>
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-blue-600 dark:text-blue-400">{rental.name}</CardTitle>
                <CardDescription>{rental.type}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-2xl font-bold text-foreground mb-3">
                  {formatPrice(convertPrice(rental.pricePerDay, rental.currency, currentGlobalCurrency))} / {t('common.day') || 'jour'}
                </p>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:opacity-90 text-white">
                  <CalendarDays className="mr-2 h-4 w-4" /> Réserver
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default RentalsPage;
