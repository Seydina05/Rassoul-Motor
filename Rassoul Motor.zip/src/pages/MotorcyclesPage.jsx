
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { useCurrency } from '@/lib/currency';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const dummyMotorcycles = [
  { id: 1, name: 'Sportive Agile Noire', price: 12000, currency: 'EUR', year: 2023, mileage: '5,000 km', imageKey: 'Sleek black sports motorcycle', features: ['ABS', 'Quickshifter', 'LED'] },
  { id: 2, name: 'Cruiser Confortable Chromé', price: 18000, currency: 'USD', year: 2022, mileage: '10,000 km', imageKey: 'Comfortable chrome cruiser motorcycle', features: ['Sacoches', 'Pare-brise', 'Custom'] },
  { id: 3, name: 'Trail Aventure Orange', price: 15000, currency: 'EUR', year: 2021, mileage: '25,000 km', imageKey: 'Orange adventure trail motorcycle', features: ['Valises alu', 'Suspensions Öhlins', 'Robuste'] },
  { id: 4, name: 'Roadster Urbain Jaune', price: 8500, currency: 'EUR', year: 2024, mileage: '1,500 km', imageKey: 'Yellow urban roadster motorcycle', features: ['Léger', 'Maniable', 'Économique'] },
  { id: 5, name: 'Scooter GT Bleu Marine', price: 4500000, currency: 'XOF', year: 2023, mileage: '8,000 km', imageKey: 'Navy blue GT scooter', features: ['Grand coffre', 'Confortable', 'Automatique'] },
];

const MotorcyclesPage = () => {
  const { t } = useI18n();
  const { formatPrice, convertPrice, currency: currentGlobalCurrency } = useCurrency();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      <header className="py-8 bg-gradient-to-r from-primary to-accent rounded-lg shadow-lg">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center text-primary-foreground">{t('motoPageTitle')}</h1>
          <p className="text-xl text-center text-primary-foreground/80 mt-2">Prêtes pour la route et l'aventure.</p>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dummyMotorcycles.map((moto, index) => (
          <motion.div
            key={moto.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden h-full flex flex-col hover:shadow-2xl transition-shadow duration-300 glassmorphism border-primary/20">
               <div className="relative h-56 w-full">
                <img className="w-full h-full object-cover" alt={moto.name} src="https://images.unsplash.com/photo-1677423973739-4cc8d866bfd1" />
                <div className="absolute top-2 right-2">
                  <Badge className="bg-accent text-accent-foreground shadow-md">{moto.year}</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-primary">{moto.name}</CardTitle>
                <CardDescription>{moto.mileage}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                 <p className="text-2xl font-bold text-foreground mb-3">
                  {formatPrice(convertPrice(moto.price, moto.currency, currentGlobalCurrency))}
                </p>
                <div className="flex flex-wrap gap-2">
                  {moto.features.map(feature => (
                    <Badge key={feature} variant="secondary" className="bg-secondary text-secondary-foreground">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground">
                  Voir les détails
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default MotorcyclesPage;
