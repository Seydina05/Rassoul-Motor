
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { Car, Bike as Motorcycle, Search, ShieldCheck, Users } from 'lucide-react';

const HomePage = () => {
  const { t } = useI18n();

  const featureCards = [
    { 
      icon: <Car className="h-10 w-10 text-primary mb-4" />, 
      title: t('nav.cars'), 
      description: "Parcourez une vaste sélection de voitures neuves et d'occasion.",
      link: "/cars"
    },
    { 
      icon: <Motorcycle className="h-10 w-10 text-primary mb-4" />, 
      title: t('nav.motorcycles'), 
      description: "Découvrez des motos pour toutes vos aventures.",
      link: "/motorcycles"
    },
    { 
      icon: <Search className="h-10 w-10 text-primary mb-4" />, 
      title: t('nav.help'), 
      description: "Besoin d'aide pour choisir ? Nos experts vous guident.",
      link: "/help"
    },
  ];

  const whyChooseUsItems = [
    { icon: <ShieldCheck className="h-8 w-8 text-green-500" />, text: "Transactions Sécurisées" },
    { icon: <Users className="h-8 w-8 text-blue-500" />, text: "Large Communauté" },
    { icon: <Car className="h-8 w-8 text-red-500" />, text: "Vaste Choix de Véhicules" },
  ];

  return (
    <div className="space-y-16">
      <motion.section 
        className="relative py-20 md:py-32 rounded-xl overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="absolute inset-0 z-0">
          <img  
            alt="Luxury car driving on a scenic road at sunset" 
            className="w-full h-full object-cover filter brightness-50"
            src="https://images.unsplash.com/photo-1693601255981-21ad394b14ef" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/20"></div>
        </div>
        
        <div className="relative z-10 container mx-auto text-center text-white">
          <motion.h1 
            className="text-4xl md:text-6xl font-extrabold mb-6 tracking-tight"
            initial={{ y: -30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.6, type: "spring", stiffness:100 }}
          >
            {t('hero.title')}
          </motion.h1>
          <motion.p 
            className="text-lg md:text-xl mb-10 max-w-3xl mx-auto text-gray-200"
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.6, type: "spring", stiffness:100 }}
          >
            {t('hero.subtitle')}
          </motion.p>
          <motion.div 
            className="space-x-4"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.5 }}
          >
            <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground transform hover:scale-105 transition-transform duration-300 shadow-lg px-8 py-6 text-lg">
              <Link to="/cars">{t('hero.findCar')}</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-primary text-primary hover:bg-primary/10 hover:text-primary-foreground transform hover:scale-105 transition-transform duration-300 shadow-lg px-8 py-6 text-lg">
              <Link to="/motorcycles">{t('hero.findMotorcycle')}</Link>
            </Button>
          </motion.div>
        </div>
      </motion.section>

      <motion.section
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h2 className="text-3xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">{t('appName')} - Votre Partenaire Mobilité</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {featureCards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
            >
              <Card className="h-full hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1 glassmorphism border-primary/20">
                <CardHeader className="items-center">
                  {card.icon}
                  <CardTitle className="text-2xl text-center">{card.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-lg">{card.description}</CardDescription>
                </CardContent>
                <div className="p-6 pt-0 text-center">
                  <Button asChild variant="link" className="text-primary text-lg">
                    <Link to={card.link}>Découvrir →</Link>
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.section>

      <motion.section
        className="py-16 bg-gradient-to-r from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 rounded-lg"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7 }}
      >
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold mb-12 text-gray-800 dark:text-gray-100">Pourquoi Choisir Rassoul Motor ?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {whyChooseUsItems.map((item, index) => (
              <motion.div 
                key={index} 
                className="flex flex-col items-center p-6 bg-white dark:bg-slate-800/50 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.15 }}
              >
                {item.icon}
                <p className="mt-4 text-lg font-semibold text-gray-700 dark:text-gray-200">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      <motion.section 
        className="text-center py-16"
        initial={{ opacity: 0, y: 50 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h2 className="text-3xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Prêt à commencer ?</h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">Rejoignez des milliers d'utilisateurs satisfaits. Vendez votre véhicule rapidement ou trouvez la voiture de vos rêves aujourd'hui.</p>
        <Button size="lg" className="bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground transform hover:scale-105 transition-transform duration-300 shadow-lg px-10 py-6 text-lg">
          <Link to="/sell">Commencer à Vendre</Link>
        </Button>
      </motion.section>

    </div>
  );
};

export default HomePage;
