
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { AlertTriangle } from 'lucide-react';

const NotFoundPage = () => {
  const { t } = useI18n();

  return (
    <motion.div 
      className="flex flex-col items-center justify-center min-h-[calc(100vh-12rem)] text-center px-4"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, type: "spring" }}
    >
      <motion.div
        animate={{ y: [0, -10, 0] }}
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
      >
        <AlertTriangle className="h-32 w-32 text-destructive mb-8" />
      </motion.div>
      
      <h1 className="text-6xl md:text-8xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-destructive to-orange-500 mb-4">
        404
      </h1>
      <p className="text-2xl md:text-3xl font-semibold text-foreground mb-6">
        {t('notFound')}
      </p>
      <p className="text-lg text-muted-foreground mb-10 max-w-md">
        {t('notFound.message') || "Oups ! La page que vous cherchez semble s'être égarée dans l'univers numérique."}
      </p>
      <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8 py-3 shadow-lg transform hover:scale-105 transition-transform">
        <Link to="/">{t('goHome')}</Link>
      </Button>

      <div className="mt-16">
        <img className="h-48 w-auto opacity-70" alt="Confused robot looking at a map" src="https://images.unsplash.com/photo-1672789210128-c9ac59de248f" />
      </div>
    </motion.div>
  );
};

export default NotFoundPage;
