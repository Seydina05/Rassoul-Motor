
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import { UploadCloud } from 'lucide-react';
import { cn } from '@/lib/utils';


const SellPage = () => {
  const { t } = useI18n();

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted");
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl mx-auto p-4 md:p-8 space-y-8"
    >
      <header className="text-center">
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent mb-4">{t('sellPageTitle')}</h1>
        <p className="text-lg text-muted-foreground">Partagez les détails de votre véhicule et trouvez un acheteur rapidement.</p>
      </header>

      <motion.form 
        onSubmit={handleSubmit} 
        className="space-y-6 p-8 rounded-xl shadow-2xl bg-card glassmorphism border-primary/20"
        initial={{ opacity:0, scale: 0.95 }}
        animate={{ opacity:1, scale: 1 }}
        transition={{ delay: 0.2, duration: 0.5}}
      >
        <div>
          <Label htmlFor="vehicleType" className="text-lg font-medium text-foreground/90">{t('sell.vehicleType') || 'Type de véhicule'}</Label>
          <Select>
            <SelectTrigger id="vehicleType" className="w-full mt-1">
              <SelectValue placeholder={t('sell.selectVehicleType') || "Sélectionnez le type"} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="car">{t('nav.cars')}</SelectItem>
              <SelectItem value="motorcycle">{t('nav.motorcycles')}</SelectItem>
              <SelectItem value="other">{t('sell.other') || 'Autre'}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="title" className="text-lg font-medium text-foreground/90">{t('sell.title') || "Titre de l'annonce"}</Label>
          <Input id="title" type="text" placeholder={t('sell.titlePlaceholder') || "Ex: Magnifique Berline Noire, Peu de KM"} className="mt-1" />
        </div>

        <div>
          <Label htmlFor="description" className="text-lg font-medium text-foreground/90">{t('sell.description') || 'Description'}</Label>
          <Textarea id="description" placeholder={t('sell.descriptionPlaceholder') || "Décrivez votre véhicule en détail..."} className="mt-1" rows={5}/>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label htmlFor="price" className="text-lg font-medium text-foreground/90">{t('sell.price') || 'Prix'}</Label>
            <Input id="price" type="number" placeholder="25000" className="mt-1" />
          </div>
          <div>
            <Label htmlFor="currency" className="text-lg font-medium text-foreground/90">{t('sell.currency') || 'Devise'}</Label>
            <Select defaultValue="EUR">
              <SelectTrigger id="currency" className="w-full mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="EUR">EUR (€)</SelectItem>
                <SelectItem value="USD">USD ($)</SelectItem>
                <SelectItem value="XOF">XOF (FCFA)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div>
          <Label htmlFor="images" className="text-lg font-medium text-foreground/90">{t('sell.images') || 'Images'}</Label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed border-input rounded-md hover:border-primary transition-colors">
            <div className="space-y-1 text-center">
              <UploadCloud className="mx-auto h-12 w-12 text-muted-foreground" />
              <div className="flex text-sm text-muted-foreground">
                <label
                  htmlFor="file-upload"
                  className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80 focus-within:outline-none focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2"
                >
                  <span>{t('sell.uploadFile') || 'Téléchargez un fichier'}</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple />
                </label>
                <p className="pl-1">{t('sell.dragAndDrop') || 'ou glissez-déposez'}</p>
              </div>
              <p className="text-xs text-muted-foreground">{t('sell.imageFormat') || 'PNG, JPG, GIF jusqu\'à 10MB'}</p>
            </div>
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground text-lg py-3 mt-4">
          {t('sell.submitAd') || "Publier l'annonce"}
        </Button>
      </motion.form>
    </motion.div>
  );
};

export default SellPage;
  