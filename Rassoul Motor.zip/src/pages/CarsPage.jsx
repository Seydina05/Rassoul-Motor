
import React from 'react';
import { useI18n } from '@/lib/i18n';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { useCurrency } from '@/lib/currency';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const PlaceholderBadge = ({ children, className, ...props }) => (
  <span className={cn("px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent rounded-full bg-primary text-primary-foreground hover:bg-primary/80", className)} {...props}>
    {children}
  </span>
);

const dummyCars = [
  { id: 1, name: 'Berline de Luxe 2023', price: 45000, currency: 'EUR', year: 2023, mileage: '15,000 km', imageKey: 'Modern luxury sedan silver', features: ['Cuir', 'GPS', 'Toit ouvrant'] },
  { id: 2, name: 'SUV Familial Spacieux', price: 32000, currency: 'EUR', year: 2022, mileage: '30,000 km', imageKey: 'White family SUV spacious interior', features: ['7 places', 'Caméra 360', 'Automatique'] },
  { id: 3, name: 'Citadine Économique', price: 15000, currency: 'EUR', year: 2021, mileage: '45,000 km', imageKey: 'Small red city car fuel efficient', features: ['Faible conso.', 'Bluetooth', 'Compacte'] },
  { id: 4, name: 'Sportive Puissante Rouge', price: 65000, currency: 'USD', year: 2024, mileage: '5,000 km', imageKey: 'Red sports car powerful engine', features: ['V8', 'Sièges sport', 'Launch control'] },
  { id: 5, name: '4x4 Robuste Vert Olive', price: 50000000, currency: 'XOF', year: 2020, mileage: '80,000 km', imageKey: 'Olive green robust 4x4 offroad', features: ['Tout-terrain', 'Snorkel', 'Treuil'] },
  { id: 6, name: 'Cabriolet Élégant Bleu Nuit', price: 55000, currency: 'EUR', year: 2022, mileage: '22,000 km', imageKey: 'Dark blue elegant convertible top down', features: ['Décapotable', 'Son Premium', 'Sièges chauffants'] },
];

const CarsPage = () => {
  const { t } = useI18n();
  const { formatPrice, convertPrice, currency: currentGlobalCurrency } = useCurrency();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      <header className="py-8 bg-gradient-to-r from-primary to-accent rounded-lg shadow-lg">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold text-center text-primary-foreground">{t('carPageTitle')}</h1>
          <p className="text-xl text-center text-primary-foreground/80 mt-2">Découvrez notre sélection exclusive.</p>
        </div>
      </header>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {dummyCars.map((car, index) => (
          <motion.div
            key={car.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden h-full flex flex-col hover:shadow-2xl transition-shadow duration-300 glassmorphism border-primary/20">
              <div className="relative h-56 w-full">
                <img className="w-full h-full object-cover" alt={car.name} src="https://images.unsplash.com/photo-1658351354155-e854d19233e0" />
                <div className="absolute top-2 right-2">
                  <Badge className="bg-accent text-accent-foreground shadow-md">{car.year}</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-primary">{car.name}</CardTitle>
                <CardDescription>{car.mileage}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow">
                <p className="text-2xl font-bold text-foreground mb-3">
                  {formatPrice(convertPrice(car.price, car.currency, currentGlobalCurrency))}
                </p>
                <div className="flex flex-wrap gap-2">
                  {car.features.map(feature => (
                    <Badge key={feature} variant="secondary" className="bg-secondary text-secondary-foreground">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 text-primary-foreground">
                  Voir les détails
                </Button>
              </CardFooter>
            </Card>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default CarsPage;
